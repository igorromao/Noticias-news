package com.example.jaxafx;

import javafx.application.Application;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.*;
import javafx.stage.Stage;
import javafx.concurrent.Task;

import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.select.Elements;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;

public class ScraperNoticiasJavaFX extends Application {

    private TextArea logArea;
    private MenuBar menuBar;

    public static void main(String[] args) {
        launch(args);
    }

    @Override
    public void start(Stage primaryStage) {
        primaryStage.setTitle("Scraper de Notícias");

        // Layout principal
        VBox root = new VBox(10);
        root.setPadding(new javafx.geometry.Insets(10));

        // Criando o MenuBar
        menuBar = new MenuBar();

        // Criando o menu "Iniciar Coleta de Notícias"
        Menu iniciarColetaMenu = new Menu("Iniciar Coleta de Notícias");

        // Criando o item de menu para iniciar a coleta de notícias
        MenuItem coletarDadosItem = new MenuItem("Iniciar Coleta de Notícias");
        coletarDadosItem.setOnAction(event -> exibirColetarDados(root));
        iniciarColetaMenu.getItems().add(coletarDadosItem);

        // Criando o menu "Coletar Dados" vazio
        Menu coletarMenu = new Menu("Coletar Dados");

        // Adicionando os menus ao MenuBar
        menuBar.getMenus().addAll(iniciarColetaMenu, coletarMenu);

        // Layout do Menu Principal
        VBox menuPrincipalLayout = new VBox(10);

        // Criando o ImageView para a imagem de notícias
        String imagemPath = "file:D:/workspace/JaxaFx/src/main/java/com/example/jaxafx/imagem/coleta_de_dados.png";  // Substitua pelo nome correto da imagem
        Image imagem = new Image(imagemPath);
        ImageView imageView = new ImageView(imagem);
        imageView.setFitHeight(300);  // Ajuste a altura
        imageView.setFitWidth(600);   // Ajuste a largura
        imageView.setPreserveRatio(true);  // Preserva a proporção da imagem

        // Criando o Label para o texto abaixo da imagem
        Label labelTexto = new Label("Doutorado: Gabrielly Champi Duarte");
        labelTexto.setStyle("-fx-font-family: 'Arial'; -fx-font-size: 20;");

        // Adicionando a imagem e o texto ao layout principal
        menuPrincipalLayout.getChildren().addAll(imageView, labelTexto);

        root.getChildren().addAll(menuBar, menuPrincipalLayout);

        // Exibe a cena
        Scene scene = new Scene(root, 600, 400);
        primaryStage.setScene(scene);
        primaryStage.show();
    }

    // Exibe os campos para coletar dados
    private void exibirColetarDados(VBox root) {
        // Layout específico para coletar dados
        VBox coletarDadosLayout = new VBox(10);

        // Botão voltar
        Button voltarButton = new Button("Voltar");
        voltarButton.setOnAction(event -> voltarAoMenuPrincipal(root));

        // ComboBox para escolher o site
        ComboBox<String> siteComboBox = new ComboBox<>();
        siteComboBox.getItems().addAll("G1", "Folha-SP");
        siteComboBox.setValue("G1");

        // Campo de entrada para número de notícias
        TextField numeroNoticiasField = new TextField();
        numeroNoticiasField.setPromptText("Digite o número de notícias");

        // Limpar os campos de log e número de notícias ao alterar a seleção do ComboBox
        siteComboBox.setOnAction(event -> {
            logArea.clear();  // Limpa a área de log
            numeroNoticiasField.clear();  // Limpa o campo de número de notícias
        });

        // Botão para iniciar o processo
        Button iniciarButton = new Button("Iniciar");

        // Área de texto para exibir logs
        logArea = new TextArea();
        logArea.setEditable(false);
        logArea.setWrapText(true);

        // Configuração do botão de iniciar
        iniciarButton.setOnAction(event -> {
            String siteEscolhido = siteComboBox.getValue();
            String input = numeroNoticiasField.getText();
            try {
                int numeroNoticias = Integer.parseInt(input);
                iniciarScraping(siteEscolhido, numeroNoticias);
            } catch (NumberFormatException e) {
                logArea.appendText("Por favor, insira um número válido.\n");
            }
        });

        // Adiciona os elementos ao layout
        coletarDadosLayout.getChildren().addAll(
                voltarButton,
                new Label("Escolha o site de notícias:"),
                siteComboBox,
                new Label("Número de Notícias:"),
                numeroNoticiasField,
                iniciarButton,
                new Label("Logs:"),
                logArea
        );

        root.getChildren().clear();  // Limpa a tela
        root.getChildren().addAll(coletarDadosLayout);  // Adiciona os novos elementos
    }

    // Função para voltar ao menu principal
    private void voltarAoMenuPrincipal(VBox root) {
        // Layout do menu principal
        VBox menuPrincipalLayout = new VBox(10);

        // Criando o ImageView para a imagem de notícias
        String imagemPath = "file:D:/workspace/JaxaFx/src/main/java/com/example/jaxafx/imagem/coleta_de_dados.png";  // Substitua pelo nome correto da imagem
        Image imagem = new Image(imagemPath);
        ImageView imageView = new ImageView(imagem);
        imageView.setFitHeight(300);  // Ajuste a altura
        imageView.setFitWidth(600);   // Ajuste a largura
        imageView.setPreserveRatio(true);  // Preserva a proporção da imagem

        // Criando o Label para o texto abaixo da imagem
        Label labelTexto = new Label("Doutorado: Gabrielly Champi Duarte");
        labelTexto.setStyle("-fx-font-family: 'Arial'; -fx-font-size: 20;");

        // Adicionando a imagem e o texto ao layout principal
        menuPrincipalLayout.getChildren().addAll(imageView, labelTexto);

        // Limpa a tela e adiciona os elementos novamente, incluindo o MenuBar
        root.getChildren().clear();
        root.getChildren().addAll(menuBar, menuPrincipalLayout);
    }

    private void iniciarScraping(String site, int limiteNoticias) {
        Task<Void> scrapingTask = new Task<>() {
            @Override
            protected Void call() {
                String urlBase;
                String seletorTitulo;
                String seletorLink;

                // Configurações de acordo com o site escolhido
                if (site.equals("G1")) {
                    urlBase = "https://g1.globo.com/ultimas-noticias";
                    seletorTitulo = "div.feed-post-body-title a.feed-post-link";
                    seletorLink = "href";
                } else if (site.equals("Folha-SP")) {
                    // No caso de Folha RSS, usamos o RSSDownloader
                    try {
                        updateMessage("Iniciando coleta de notícias da Folha...\n");
                        RSSDownloader.downloadRSSFeeds(limiteNoticias);  // Chama a função para coletar as notícias da Folha
                        updateMessage("Coleta de notícias da Folha concluída.\n");
                        return null;
                    } catch (Exception e) {
                        updateMessage("Erro ao coletar notícias da Folha: " + e.getMessage() + "\n");
                        return null;
                    }
                } else {
                    updateMessage("Site não suportado.\n");
                    return null;
                }

                int pagina = 1;
                int contador = 0;

                while (contador < limiteNoticias) {
                    try {
                        String url = urlBase;
                        updateMessage("Acessando a página: " + url + "\n");

                        Document doc = Jsoup.connect(url).get();
                        System.out.println(doc);
                        Elements noticias = doc.select(seletorTitulo);

                        System.out.println(noticias);

                        for (org.jsoup.nodes.Element noticia : noticias) {
                            if (contador >= limiteNoticias) break;

                            String titulo = noticia.text();
                            String link = noticia.absUrl(seletorLink);

                            // Baixa o conteúdo da notícia
                            String conteudoNoticia = baixarNoticia(link, site);
                            salvarNoticiaEmArquivo(contador + 1, conteudoNoticia, site);
                            updateMessage("Notícia " + (contador + 1) + " salva.\n");
                            contador++;
                        }

                        break;
                    } catch (IOException e) {
                        updateMessage("Erro ao acessar página: " + e.getMessage() + "\n");
                    }

                    try {
                        Thread.sleep(2000); // Espera 2 segundos entre as requisições
                    } catch (InterruptedException e) {
                        Thread.currentThread().interrupt();
                    }
                }

                updateMessage("Processo de coleta de notícias finalizado.\n");
                return null;
            }
        };

        // Atualiza os logs na área de texto
        scrapingTask.messageProperty().addListener((obs, oldMessage, newMessage) -> logArea.appendText(newMessage));

        // Executa a tarefa em uma nova thread
        new Thread(scrapingTask).start();
    }

    private String baixarNoticia(String link, String site) throws IOException {
        Document doc = Jsoup.connect(link)
                .userAgent("Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/115.0.0.0 Safari/537.36")
                .get();

        String corpo;

        // Verifica o site escolhido e ajusta o seletor de acordo
        if (site.equals("G1")) {
            corpo = doc.select("div.content-text").text();  // Seletor para o G1
        } else {
            corpo = "Conteúdo não disponível.";
        }

        return corpo;
    }

    private void salvarNoticiaEmArquivo(int numeroNoticia, String conteudoNoticia, String site) {
        try {
            // Verifica se o conteúdo da notícia está vazio ou nulo
            if (conteudoNoticia == null || conteudoNoticia.trim().isEmpty()) {
                System.out.println("Notícia " + numeroNoticia + " não possui conteúdo e não será salva.");
                return; // Não salva o arquivo
            }

            // Define o caminho da pasta
            String caminhoPasta = "D:\\downloads\\noticias\\" + (site.equals("Folha-SP") ? "Folha" : site);

            // Cria o diretório onde as notícias serão salvas, se não existir
            File diretorio = new File(caminhoPasta);
            if (!diretorio.exists()) {
                boolean pastaCriada = diretorio.mkdirs();  // Cria os diretórios, se não existirem
                if (pastaCriada) {
                    System.out.println("Pasta criada: " + caminhoPasta);
                } else {
                    System.out.println("Falha ao criar a pasta: " + caminhoPasta);
                }
            }

            // Gera o nome do arquivo personalizado
            String nomeArquivo = "Noticia" + numeroNoticia + "-folha.txt";

            // Substitui caracteres inválidos no nome do arquivo (exemplo: espaços, acentos, etc.)
            nomeArquivo = nomeArquivo.replaceAll("[^a-zA-Z0-9.-]", "_");

            // Cria e escreve no arquivo
            BufferedWriter writer = new BufferedWriter(new FileWriter(new File(diretorio, nomeArquivo)));
            writer.write(conteudoNoticia);
            writer.close();
            System.out.println("Notícia " + numeroNoticia + " salva com sucesso.");
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

}
