package com.example.jaxafx;

import com.rometools.rome.io.SyndFeedInput;
import com.rometools.rome.feed.synd.SyndFeed;
import com.rometools.rome.feed.synd.SyndEntry;
import org.jsoup.Jsoup;
import java.io.FileWriter;
import java.io.IOException;
import java.net.URL;
import java.util.List;
import java.io.InputStreamReader;
import java.io.File;

public class RSSDownloader {

    public static void downloadRSSFeeds(int limiteNoticias) {
        String[] rssUrls = {
                "https://feeds.folha.uol.com.br/ambiente/rss091.xml",
                "https://feeds.folha.uol.com.br/poder/rss091.xml",
                "https://feeds.folha.uol.com.br/emcimadahora/rss091.xml",
                "https://feeds.folha.uol.com.br/opiniao/rss091.xml",
                "https://feeds.folha.uol.com.br/mundo/rss091.xml",
                "https://feeds.folha.uol.com.br/mercado/rss091.xml",
                "https://feeds.folha.uol.com.br/cotidiano/rss091.xml",
                "https://feeds.folha.uol.com.br/educacao/rss091.xml",
                "https://feeds.folha.uol.com.br/equilibrio/rss091.xml",
                "https://feeds.folha.uol.com.br/esporte/rss091.xml",
                "https://feeds.folha.uol.com.br/ciencia/rss091.xml",
                "https://feeds.folha.uol.com.br/turismo/rss091.xml"
        };

        // Defina o diretório para salvar os arquivos
        String saveDirectory = "D:/downloads/noticias/";

        // Cria o diretório caso não exista
        File dir = new File(saveDirectory);
        if (!dir.exists()) {
            dir.mkdirs();
        }

        int contador = 0;
        for (String rssUrl : rssUrls) {
            if (contador >= limiteNoticias) break;
            try {
                // Baixando e processando o feed RSS com codificação UTF-8
                SyndFeed feed = new SyndFeedInput().build(new InputStreamReader(new URL(rssUrl).openStream(), "ISO-8859-1"));

                // Iterando sobre as notícias do feed
                List<SyndEntry> entries = feed.getEntries();
                for (SyndEntry entry : entries) {
                    if (contador >= limiteNoticias) break;
                    // Gerando um nome de arquivo único para cada notícia (baseado no título)
                    String fileName = saveDirectory + entry.getTitle().replaceAll("[^a-zA-Z0-9]", "_") + ".txt";
                    FileWriter writer = new FileWriter(fileName);

                    // Remover as tags HTML da descrição
                    String descricaoLimpa = Jsoup.parse(entry.getDescription().getValue()).text();

                    // Escrevendo os dados da notícia no arquivo
                    writer.write("Título: " + entry.getTitle() + "\n");
                    writer.write("Link: " + entry.getLink() + "\n");
                    writer.write("Data de publicação: " + entry.getPublishedDate() + "\n");
                    writer.write("Descrição: " + descricaoLimpa + "\n");

                    writer.close();
                    System.out.println("Notícia salva em: " + fileName);
                    contador++;
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }
}
