module com.example.jaxafx {
    requires javafx.controls;
    requires javafx.fxml;

    requires org.kordamp.bootstrapfx.core;
    requires org.jsoup;
    requires com.rometools.rome;
    requires org.apache.commons.lang3;

    opens com.example.jaxafx to javafx.fxml;
    exports com.example.jaxafx;
}